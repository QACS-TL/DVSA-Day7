a = 42
b = 9
print(a + b)

a = 'Hello '
b = 'World!'
print(a + b)

