def square(number):
    print(number,"squared =",number*number)

for i in range(10):
    square(i)
