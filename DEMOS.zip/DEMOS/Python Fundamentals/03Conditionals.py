number = input("Please enter a number: ")
if number == 10:
    print("It's a 10!")
else:
    print("It's NOT a 10")

print("All strings:")
if number == "10":
    print("It's a 10!")
else:
    print("It's NOT a 10")

print("All numbers:")
number = int(number)
if number == 10:
    print("It's a 10!")
else:
    print("It's NOT a 10")
