mark = int(input("Enter mark: "))

if mark > 65:
    print("Pass")
else:
    print("Fail")
