class Account:
    balance = 0
    number = "13456789"
    type = "Current"

my_acc = Account()
my_acc.balance = 50.00
my_acc.number = "987654321"

print(f"Your account no is {my_acc.number} "
      + f"and it contains £{my_acc.balance:0.2f}")
