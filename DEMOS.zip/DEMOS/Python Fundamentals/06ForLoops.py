names = [ "Anne", "Sue", "Pete" ]
for name in names:
   print(name)
