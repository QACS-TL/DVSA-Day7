def addition(number1,number2):
    print(number1,"+",number2,"=",number1 + number2)

for i in range(3):
    for j in range(4):
        addition(i,j)
