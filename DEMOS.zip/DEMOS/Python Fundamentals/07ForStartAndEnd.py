for i in range(5,10):
    print("i:",i)
