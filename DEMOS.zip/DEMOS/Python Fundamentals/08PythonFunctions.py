def make_list(val, times):    
   res = str(val) * times 
   return res

starry_line = make_list("*", 20)
print(starry_line)