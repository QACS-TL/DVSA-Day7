def calc_vat(gross):
    vatpc = 20
    net = gross/(1 + (vatpc/100))
    vat = gross - net
    return [f'{net:05.2f}', f'{vat:05.2f}']

result = calc_vat(120.00)
print(result)

print(calc_vat(9.55))

