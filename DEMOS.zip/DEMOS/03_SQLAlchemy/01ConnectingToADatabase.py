from flask import Flask
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)

connection_url = 'sqlite:///people.db'
app.config['SQLALCHEMY_DATABASE_URI'] = connection_url

db = SQLAlchemy(app)

class Person(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    firstname = db.Column(db.String(30))
    lastname = db.Column(db.String(30))

# include the following if the database or any of its table don't yet exist. 
# If they do then nothing will be touched.    
# with app.app_context():
#     db.create_all()

@app.route('/people')
def read():
    query = db.session.query(Person)
    all_people = query.all()
    people_string = ""
    for person in all_people:
        people_string += "<br>" + person.firstname + " " + person.lastname
    return people_string

if __name__ == '__main__':
    app.run()