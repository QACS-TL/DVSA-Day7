from flask import Flask
from flask_sqlalchemy import SQLAlchemy


app = Flask(__name__)

connection_url = 'sqlite:///people.db'
app.config['SQLALCHEMY_DATABASE_URI'] = connection_url

db = SQLAlchemy(app)

class Person(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    firstname = db.Column(db.String(30))
    lastname = db.Column(db.String(30))
    postcode = db.Column(db.String(10))

@app.route('/people')
def read():
    query = db.session.query(Person)
    all_people = query.all()
    people_string = ""
    for person in all_people:
        people_string += "<br>" + person.firstname + " " + person.lastname
    return people_string

@app.route('/people_by_start_of_address/<string:postcode_start>')
def people_by_start_of_postcode(postcode_start):
    query = db.session.query(Person)
    all_people = query.filter(Person.postcode.startswith(postcode_start)).order_by(Person.lastname).all()
    people_string = ""
    for person in all_people:
        people_string += f"<br> Person: {person.lastname}, PostCode: {person.postcode}"
    return people_string

@app.route('/update_person/<int:id>/<string:lastname>')
def update(id, lastname):
    query = db.session.query(Person)
    person = query.get(id)
    person.lastname = lastname
    db.session.commit()
    return f"The person with an id of {id} has had their last name changed successfully"

@app.route('/add_person')
def add():
    new_person = Person(
        firstname="Sadia", lastname="Saleem",
        postcode="SW19 3FG")
    db.session.add(new_person)
    db.session.commit()
    return "Added new person to database"

@app.route('/delete_person/<int:id>')
def delete(id):
    query = db.session.query(Person)
    person = query.get(id)
    db.session.delete(person)
    db.session.commit()
    return f"The person with an id of {id} has been successfully deleted"

if __name__ == '__main__':
    app.run()
