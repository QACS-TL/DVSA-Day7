from flask import Flask, Response, jsonify
from flask_sqlalchemy import SQLAlchemy
from dataclasses import dataclass



app = Flask(__name__)

connection_url = 'sqlite:///vehicles.db'
app.config['SQLALCHEMY_DATABASE_URI'] = connection_url

db = SQLAlchemy(app)

@dataclass
class Customers(db.Model):
    customerid:str = db.Column(db.String(5), primary_key=True)
    companyname:str = db.Column(db.String(40))
    contactname:str = db.Column(db.String(30))
    contacttitle:str = db.Column(db.String(30))
    address:str = db.Column(db.String(60))
    city:str = db.Column(db.String(15))
    region:str = db.Column(db.String(15))
    postalcode:str = db.Column(db.String(10))
    country:str = db.Column(db.String(15))
    phone:str = db.Column(db.String(24))
    fax:str = db.Column(db.String(24))


@app.route('/customers', methods=['GET'])
def customers():
    query = db.session.query(Customers)
    all_customers = query.all()
    customers_string = ""
    for customer in all_customers:
        customers_string += "<br>" + customer.companyname
    return Response(customers_string, mimetype='text/plain')

@app.route('/get_customer_as_json/<string:customerid>', methods=['GET'])
def get_customer_as_json(customerid):
    query = db.session.query(Customers)
    customer = query.get(customerid)
    if customer is not None:
        customer_as_json = jsonify(customer)
        return customer_as_json
        # Alternate solution that uses Response method
        # customer_as_data = customer_as_json.data
        # return Response(customer_as_data, mimetype='application/json')
    else:
        return Response("No such customer", mimetype='text/plain')

@app.route('/customers_as_json', methods=['GET'])
def customers_as_json():
    query = db.session.query(Customers)
    all_customers = query.all()
    custs_dict = {}
    for cust in all_customers:
        cust_dict = {'customerid': cust.customerid,
                     'companyname': cust.companyname,
                     'contactname': cust.contactname}
        custs_dict[cust_dict.get('customerid')] = cust_dict
    json_custs_dict = jsonify(custs_dict)
    # return json_custs_dict
    return Response(json_custs_dict, mimetype='text/json')

@app.route('/update_customer_name/<customerid>/<name>', methods=['POST'])
def update_customer_name(customerid, name):
    query = db.session.query(Customers)
    customer = query.get(customerid)
    if customer is not None:
        customer.companyname = name
        db.session.commit()
        return Response(f"customer with id of {customerid} has been successfully changed to {customer.companyname}", mimetype='text/plain')
    else:
        return Response(f"Customer {customerid} not in database", mimetype='text/plain')

@app.route('/add_customer/<string:customerid>/<string:companyname>/<string:contactname>/<string:contacttitle>/<string:address>/<string:city>/<string:region>/<string:postalcode>/<string:country>/<string:phone>/<string:fax>', methods=['POST'])
def add_customer(customerid, companyname, contactname, contacttitle, address, city, region, postalcode, country, phone, fax):
    query = db.session.query(Customers)
    customer = query.get(customerid)
    if customer is None:
        new_customer = Customers(customerid=customerid,
                             companyname=companyname,
                             contactname=contactname,
                             contacttitle=contacttitle,
                             address=address,
                             city=city,
                             region=region,
                             postalcode=postalcode,
                             country=country,
                             phone=phone,
                             fax=fax)
        db.session.add(new_customer)
        db.session.flush()
        db.session.refresh(new_customer)  # Would be relevant if customerid column is defined as an integer identity
        db.session.commit()
        return f"Added new customer with a company id of {new_customer.customerid} to the database"
    else:
        return f"A customer with an id of {customerid} is already in the customers table"


@app.route('/delete_customer/<string:customerid>', methods=['POST'])
def delete_customer(customerid):
    query = db.session.query(Customers)
    customer = query.get(customerid)
    if customer is not None:
        db.session.delete(customer)
        db.session.commit()
        return f"The customer with a company id of {customer.customerid} has been successfully removed from the database"
    else:
        return f"Deletion Failed! A customer with an id of {customerid} does not exist in the customers table"

if __name__ == '__main__':
    app.run()
