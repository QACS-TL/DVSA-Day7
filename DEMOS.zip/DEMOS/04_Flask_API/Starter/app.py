from flask import Flask, Response, jsonify
from flask_sqlalchemy import SQLAlchemy
from dataclasses import dataclass



app = Flask(__name__)

connection_url = 'mssql+pyodbc://(local)/Northwind?driver=SQL+Server&trusted_connection=yes'
app.config['SQLALCHEMY_DATABASE_URI'] = connection_url

db = SQLAlchemy(app)

@dataclass
class Customers(db.Model):
    customerid:str = db.Column(db.String(5), primary_key=True)
    companyname:str = db.Column(db.String(40))
    contactname:str = db.Column(db.String(30))
    contacttitle:str = db.Column(db.String(30))
    address:str = db.Column(db.String(60))
    city:str = db.Column(db.String(15))
    region:str = db.Column(db.String(15))
    postalcode:str = db.Column(db.String(10))
    country:str = db.Column(db.String(15))
    phone:str = db.Column(db.String(24))
    fax:str = db.Column(db.String(24))

# Add new routes here



if __name__ == '__main__':
    app.run()
