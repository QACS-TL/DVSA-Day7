from flask import Flask, request, jsonify

app = Flask(__name__)

@app.route('/home/<word>')
def home(word):
    return word.upper()


if __name__ == '__main__':
    app.run()
