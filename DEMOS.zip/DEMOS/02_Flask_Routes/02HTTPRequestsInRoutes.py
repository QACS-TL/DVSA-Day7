from flask import Flask, request, jsonify

app = Flask(__name__)

@app.route('/home', methods=['GET', 'POST'])
def home():
    if request.method == 'POST':
        response_data = 'This is a POST request'
    else:
        response_data = 'This is a GET request'

    return response_data

if __name__ == '__main__':
    app.run()